console.log("Hello World");
var a=1;
var b=2;
var r= a+b;
var multi= a*b
console.log("Resultado: " + r);
console.log("Resultado de la multiplicacion: " + multi);
var raiz= Math.sqrt(1800)
console.log("El resultado de la Raíz es: " + raiz); 
var n3= 1800
var raiz2=Math.trunc(raiz)
console.log("El resultado de la Raíz aproximada es: " + raiz2);

var c = 500000;
var j = 2;
var numerosPrimos = [];

for (; j < c; j++) {

  if (primo(j)) {
    numerosPrimos.push(j);
  }
  
}

console.log("Los numero primos hasta el 500.000 son: " + numerosPrimos);

function primo(numero) {

  for (var i = 2; i < numero; i++) {

    if (numero % i === 0) {
      return false;
    }

  }

  return numero !== 1;
}